<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent; 


class main extends AbstractForm
{

    /**
     * @event image6.click-Left 
     */
    function doImage6ClickLeft(UXMouseEvent $event = null)
    {    
		app()->minimizeForm($this->getContextFormName());

        
    }

    /**
     * @event image5.click-Left 
     */
    function doImage5ClickLeft(UXMouseEvent $event = null)
    {    
		$this->showPreloader('');
		waitAsync(1500, function () use ($event) {
			$this->hidePreloader();
			app()->shutdown();
		});

        
    }

    /**
     * @event image10.mouseEnter 
     */
    function doImage10MouseEnter(UXMouseEvent $event = null)
    {    
		$this->toast('Downloading \'Russian Voice Pack\' by TRW...');

        
    }

    /**
     * @event link.click 
     */
    function doLinkClick(UXMouseEvent $event = null)
    {    
		browse('http://bluebyte.tk');

        
    }

    /**
     * @event image3.mouseDown-Left 
     */
    function doImage3MouseDownLeft(UXMouseEvent $event = null)
    {    
		$this->menupanel->show();
		$this->menuplay->show();
		$this->menuviewmodlist->show();
		$this->menuauthors->show();

        
    }

}
