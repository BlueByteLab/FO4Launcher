<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXWindowEvent; 


class loader extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $event = null)
    {    
		waitAsync(2500, function () use ($event) {
			$this->loadForm('main', false, true);
		});

        
    }

}
